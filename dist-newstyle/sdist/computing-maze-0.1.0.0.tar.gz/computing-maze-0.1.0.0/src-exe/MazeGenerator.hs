module MazeGenerator where

import Control.Monad (foldM, forM)
import System.Random (randomRIO)
import Data.IORef
import Matrix (generateMatrix, updateMatrix, numRows, numCols)

-- Gera o labirinto
generateMaze :: Int -> Int -> IO [[Int]]
generateMaze width height = do
    -- Gera a matriz inicial
    let finalWidth = width * 2 + 1
        finalHeight = height * 2 + 1
    let maze = generateMatrix finalWidth finalHeight 0
    let visited = generateMatrix finalWidth finalHeight False
    -- Inicia a geração do labirinto
    recursiveTraverse 1 1 maze visited

-- Função para embaralhar a lista de direções
shuffle :: [a] -> IO [a]
shuffle xs = do
    ref <- newIORef xs
    forM [1..n] $ \i -> do
        j <- randomRIO (i, n)
        xs' <- readIORef ref
        let (beforeI, atI:afterI) = splitAt (i-1) xs'
        let (beforeJ, atJ:afterJ) = splitAt (j-1) afterI
        let newList = beforeI ++ [atJ] ++ afterJ ++ [atI]
        writeIORef ref newList
    readIORef ref
  where
    n = length xs

-- Função recursiva para modificar o maze
recursiveTraverse :: Int -> Int -> [[Int]] -> [[Bool]] -> IO [[Int]]
recursiveTraverse x y maze visited = do
    if checkCell x y maze visited then do
        -- Atualiza o maze e o visited
        let maze' = updateMatrix maze x y 1
        let visited' = updateMatrix visited x y True
        -- Obtém as direções possíveis e embaralha
        directions <- shuffle [(0, 1), (1, 0), (0, -1), (-1, 0)]
        -- Itera sobre as direções e chama recursivamente
        foldM (\maze'' (dx, dy) -> do
            let (nx, ny) = (x + dx * 2, y + dy * 2)
            recursiveTraverse nx ny maze'' visited'
            ) maze' directions
    else
        -- Se a posição não é válida ou já foi visitada, retorna o maze atual
        return maze

-- Função para checar se a célula é válida para ser um caminho
checkCell :: Int -> Int -> [[Int]] -> [[Bool]] -> Bool
checkCell x y maze visited =
    (0 <= x && x < numRows maze) && (0 <= y && y < numCols maze) && not (visited !! x !! y)
